
def parse_quiz_output(quiz_text):
    return quiz_text.strip().split("\n\n")  # Splits each question block
