from flask import Flask, render_template, request
from llama_api import generate_quiz

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        topic = request.form["topic"]
        try:
            quiz = generate_quiz(topic)
            return render_template("quiz.html", topic=topic, quiz=quiz)
        except Exception as e:
            return f"Error: {e}"
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
